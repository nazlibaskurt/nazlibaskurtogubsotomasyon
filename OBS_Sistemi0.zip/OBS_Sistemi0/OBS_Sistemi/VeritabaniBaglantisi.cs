﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OBS_Sistemi
{
    internal class VeritabaniBaglantisi
    {
        public static MySqlConnection BaglantiGetir()
        {
            string connectionString = "server=localhost;database=OBS;uid=root;pwd=1234;";
            return new MySqlConnection(connectionString);
        }
    }
}
