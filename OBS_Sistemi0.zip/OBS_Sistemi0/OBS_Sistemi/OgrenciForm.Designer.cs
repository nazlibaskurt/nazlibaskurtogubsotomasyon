﻿namespace OBS_Sistemi
{
    partial class OgrenciForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.cmbDersler = new System.Windows.Forms.ComboBox();
            this.btnDersSec = new System.Windows.Forms.Button();
            this.btnDersSil = new System.Windows.Forms.Button();
            this.btnDersGuncelle = new System.Windows.Forms.Button();
            this.dgvSecilenDersler = new System.Windows.Forms.DataGridView();
            ((System.ComponentModel.ISupportInitialize)(this.dgvSecilenDersler)).BeginInit();
            this.SuspendLayout();
            // 
            // cmbDersler
            // 
            this.cmbDersler.FormattingEnabled = true;
            this.cmbDersler.Location = new System.Drawing.Point(12, 46);
            this.cmbDersler.Name = "cmbDersler";
            this.cmbDersler.Size = new System.Drawing.Size(121, 24);
            this.cmbDersler.TabIndex = 0;
            // 
            // btnDersSec
            // 
            this.btnDersSec.Location = new System.Drawing.Point(160, 47);
            this.btnDersSec.Name = "btnDersSec";
            this.btnDersSec.Size = new System.Drawing.Size(75, 23);
            this.btnDersSec.TabIndex = 1;
            this.btnDersSec.Text = "Ders Seç";
            this.btnDersSec.UseVisualStyleBackColor = true;
            this.btnDersSec.Click += new System.EventHandler(this.btnDersSec_Click);
            // 
            // btnDersSil
            // 
            this.btnDersSil.Location = new System.Drawing.Point(160, 97);
            this.btnDersSil.Name = "btnDersSil";
            this.btnDersSil.Size = new System.Drawing.Size(75, 23);
            this.btnDersSil.TabIndex = 2;
            this.btnDersSil.Text = "Ders Sil";
            this.btnDersSil.UseVisualStyleBackColor = true;
            // 
            // btnDersGuncelle
            // 
            this.btnDersGuncelle.Location = new System.Drawing.Point(160, 156);
            this.btnDersGuncelle.Name = "btnDersGuncelle";
            this.btnDersGuncelle.Size = new System.Drawing.Size(75, 23);
            this.btnDersGuncelle.TabIndex = 3;
            this.btnDersGuncelle.Text = "Ders Güncelleme";
            this.btnDersGuncelle.UseVisualStyleBackColor = true;
            this.btnDersGuncelle.Click += new System.EventHandler(this.btnDersGuncelle_Click);
            // 
            // dgvSecilenDersler
            // 
            this.dgvSecilenDersler.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvSecilenDersler.Location = new System.Drawing.Point(284, 46);
            this.dgvSecilenDersler.Name = "dgvSecilenDersler";
            this.dgvSecilenDersler.RowHeadersWidth = 51;
            this.dgvSecilenDersler.RowTemplate.Height = 24;
            this.dgvSecilenDersler.Size = new System.Drawing.Size(240, 150);
            this.dgvSecilenDersler.TabIndex = 4;
            this.dgvSecilenDersler.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvSecilenDersler_CellContentClick);
            // 
            // OgrenciForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.dgvSecilenDersler);
            this.Controls.Add(this.btnDersGuncelle);
            this.Controls.Add(this.btnDersSil);
            this.Controls.Add(this.btnDersSec);
            this.Controls.Add(this.cmbDersler);
            this.Name = "OgrenciForm";
            this.Text = "OgrenciForm";
            ((System.ComponentModel.ISupportInitialize)(this.dgvSecilenDersler)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.ComboBox cmbDersler;
        private System.Windows.Forms.Button btnDersSec;
        private System.Windows.Forms.Button btnDersSil;
        private System.Windows.Forms.Button btnDersGuncelle;
        private System.Windows.Forms.DataGridView dgvSecilenDersler;
    }
}