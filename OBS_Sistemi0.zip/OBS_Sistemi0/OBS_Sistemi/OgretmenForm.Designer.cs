﻿namespace OBS_Sistemi
{
    partial class OgretmenForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.dgvOgrenciDersleri = new System.Windows.Forms.DataGridView();
            this.btnDersOnayla = new System.Windows.Forms.Button();
            this.btnDersRed = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dgvOgrenciDersleri)).BeginInit();
            this.SuspendLayout();
            // 
            // dgvOgrenciDersleri
            // 
            this.dgvOgrenciDersleri.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvOgrenciDersleri.Location = new System.Drawing.Point(0, 0);
            this.dgvOgrenciDersleri.Name = "dgvOgrenciDersleri";
            this.dgvOgrenciDersleri.RowHeadersWidth = 51;
            this.dgvOgrenciDersleri.Size = new System.Drawing.Size(240, 150);
            this.dgvOgrenciDersleri.TabIndex = 0;
            this.dgvOgrenciDersleri.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellContentClick);
            // 
            // btnDersOnayla
            // 
            this.btnDersOnayla.Location = new System.Drawing.Point(263, 154);
            this.btnDersOnayla.Name = "btnDersOnayla";
            this.btnDersOnayla.Size = new System.Drawing.Size(75, 23);
            this.btnDersOnayla.TabIndex = 1;
            this.btnDersOnayla.Text = "Ders Onayla";
            this.btnDersOnayla.UseVisualStyleBackColor = true;
            this.btnDersOnayla.Click += new System.EventHandler(this.btnDersOnayla_Click);
            // 
            // btnDersRed
            // 
            this.btnDersRed.Location = new System.Drawing.Point(263, 209);
            this.btnDersRed.Name = "btnDersRed";
            this.btnDersRed.Size = new System.Drawing.Size(75, 23);
            this.btnDersRed.TabIndex = 2;
            this.btnDersRed.Text = "Reddet";
            this.btnDersRed.UseVisualStyleBackColor = true;
            this.btnDersRed.Click += new System.EventHandler(this.btnDersRed_Click);
            // 
            // OgretmenForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.btnDersRed);
            this.Controls.Add(this.btnDersOnayla);
            this.Controls.Add(this.dgvOgrenciDersleri);
            this.Name = "OgretmenForm";
            this.Text = "OgretmenForm";
            this.Load += new System.EventHandler(this.OgretmenForm_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgvOgrenciDersleri)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.DataGridView dgvOgrenciDersleri;
        private System.Windows.Forms.Button btnDersOnayla;
        private System.Windows.Forms.Button btnDersRed;
    }
}