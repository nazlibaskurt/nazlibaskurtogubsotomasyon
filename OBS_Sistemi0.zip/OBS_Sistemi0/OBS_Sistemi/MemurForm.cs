﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace OBS_Sistemi
{
    public partial class MemurForm : Form
    {
        public MemurForm()
        {
            InitializeComponent();
        }

        private void btnEkle_Click(object sender, EventArgs e)
        {
            MySqlConnection con = VeritabaniBaglantisi.BaglantiGetir();
            con.Open();

            string query = "INSERT INTO Ogrenciler (Ad, Soyad, OgrenciNo, Sifre) VALUES (@Ad, @Soyad, @OgrenciNo, @Sifre)";
            MySqlCommand cmd = new MySqlCommand(query, con);
            cmd.Parameters.AddWithValue("@Ad", txtAd.Text);
            cmd.Parameters.AddWithValue("@Soyad", txtSoyad.Text);
            cmd.Parameters.AddWithValue("@OgrenciNo", txtOgrenciNo.Text);
            cmd.Parameters.AddWithValue("@Sifre", "1234");

            cmd.ExecuteNonQuery();
            con.Close();

            MessageBox.Show("Öğrenci başarıyla eklendi.");
            
        }

        private void btnGuncelle_Click(object sender, EventArgs e)
        {
            
            {
                MySqlConnection con = VeritabaniBaglantisi.BaglantiGetir();
                con.Open();

                string query = "SELECT * FROM Ogrenciler";
                MySqlDataAdapter da = new MySqlDataAdapter(query, con);
                DataTable dt = new DataTable();
                da.Fill(dt);

                dgvOgrenciler.DataSource = dt;
                con.Close();
            }
        }
    }
}
