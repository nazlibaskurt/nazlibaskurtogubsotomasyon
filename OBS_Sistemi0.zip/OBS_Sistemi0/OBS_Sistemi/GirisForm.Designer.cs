﻿namespace OBS_Sistemi
{
    partial class GirisForm
    {
        /// <summary>
        ///Gerekli tasarımcı değişkeni.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///Kullanılan tüm kaynakları temizleyin.
        /// </summary>
        ///<param name="disposing">yönetilen kaynaklar dispose edilmeliyse doğru; aksi halde yanlış.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer üretilen kod

        /// <summary>
        /// Tasarımcı desteği için gerekli metot - bu metodun 
        ///içeriğini kod düzenleyici ile değiştirmeyin.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblKullaniciTuru = new System.Windows.Forms.Label();
            this.cmbKullaniciTuru = new System.Windows.Forms.ComboBox();
            this.lblKullaiciAdi = new System.Windows.Forms.Label();
            this.txtKullaniciAdi = new System.Windows.Forms.TextBox();
            this.lblSifre = new System.Windows.Forms.Label();
            this.txtSifre = new System.Windows.Forms.TextBox();
            this.btnGiris = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lblKullaniciTuru
            // 
            this.lblKullaniciTuru.AutoSize = true;
            this.lblKullaniciTuru.Location = new System.Drawing.Point(29, 32);
            this.lblKullaniciTuru.Name = "lblKullaniciTuru";
            this.lblKullaniciTuru.Size = new System.Drawing.Size(86, 16);
            this.lblKullaniciTuru.TabIndex = 0;
            this.lblKullaniciTuru.Text = "Kullanıcı Türü";
            // 
            // cmbKullaniciTuru
            // 
            this.cmbKullaniciTuru.FormattingEnabled = true;
            this.cmbKullaniciTuru.Items.AddRange(new object[] {
            "Memur",
            "Öğrenci",
            "Öğretmen"});
            this.cmbKullaniciTuru.Location = new System.Drawing.Point(32, 77);
            this.cmbKullaniciTuru.Name = "cmbKullaniciTuru";
            this.cmbKullaniciTuru.Size = new System.Drawing.Size(121, 24);
            this.cmbKullaniciTuru.TabIndex = 1;
            // 
            // lblKullaiciAdi
            // 
            this.lblKullaiciAdi.AutoSize = true;
            this.lblKullaiciAdi.Location = new System.Drawing.Point(183, 32);
            this.lblKullaiciAdi.Name = "lblKullaiciAdi";
            this.lblKullaiciAdi.Size = new System.Drawing.Size(79, 16);
            this.lblKullaiciAdi.TabIndex = 2;
            this.lblKullaiciAdi.Text = "Kullanıcı Adı";
            // 
            // txtKullaniciAdi
            // 
            this.txtKullaniciAdi.Location = new System.Drawing.Point(186, 79);
            this.txtKullaniciAdi.Name = "txtKullaniciAdi";
            this.txtKullaniciAdi.Size = new System.Drawing.Size(100, 22);
            this.txtKullaniciAdi.TabIndex = 3;
            // 
            // lblSifre
            // 
            this.lblSifre.AutoSize = true;
            this.lblSifre.Location = new System.Drawing.Point(337, 32);
            this.lblSifre.Name = "lblSifre";
            this.lblSifre.Size = new System.Drawing.Size(34, 16);
            this.lblSifre.TabIndex = 4;
            this.lblSifre.Text = "Şifre";
            // 
            // txtSifre
            // 
            this.txtSifre.Location = new System.Drawing.Point(340, 79);
            this.txtSifre.Name = "txtSifre";
            this.txtSifre.PasswordChar = '*';
            this.txtSifre.Size = new System.Drawing.Size(100, 22);
            this.txtSifre.TabIndex = 5;
            // 
            // btnGiris
            // 
            this.btnGiris.Location = new System.Drawing.Point(472, 79);
            this.btnGiris.Name = "btnGiris";
            this.btnGiris.Size = new System.Drawing.Size(75, 22);
            this.btnGiris.TabIndex = 6;
            this.btnGiris.Text = "Giriş Yap";
            this.btnGiris.UseVisualStyleBackColor = true;
            this.btnGiris.Click += new System.EventHandler(this.btnGiris_Click);
            // 
            // GirisForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.btnGiris);
            this.Controls.Add(this.txtSifre);
            this.Controls.Add(this.lblSifre);
            this.Controls.Add(this.txtKullaniciAdi);
            this.Controls.Add(this.lblKullaiciAdi);
            this.Controls.Add(this.cmbKullaniciTuru);
            this.Controls.Add(this.lblKullaniciTuru);
            this.Name = "GirisForm";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblKullaniciTuru;
        private System.Windows.Forms.ComboBox cmbKullaniciTuru;
        private System.Windows.Forms.Label lblKullaiciAdi;
        private System.Windows.Forms.TextBox txtKullaniciAdi;
        private System.Windows.Forms.Label lblSifre;
        private System.Windows.Forms.TextBox txtSifre;
        private System.Windows.Forms.Button btnGiris;
    }
}

