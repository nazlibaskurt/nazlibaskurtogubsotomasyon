﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace OBS_Sistemi
{
    public partial class OgrenciForm : Form
    {
        public OgrenciForm()
        {
            InitializeComponent();
        }

        private void btnDersGuncelle_Click(object sender, EventArgs e)
        {
            
            {
                MySqlConnection con = VeritabaniBaglantisi.BaglantiGetir();
                con.Open();

                string query = "SELECT * FROM Dersler";
                MySqlDataAdapter da = new MySqlDataAdapter(query, con);
                DataTable dt = new DataTable();
                da.Fill(dt);

                cmbDersler.DataSource = dt;
                cmbDersler.DisplayMember = "DersAdi";
                cmbDersler.ValueMember = "DersID";

                con.Close();
            }

        }

        private void btnDersSec_Click(object sender, EventArgs e)
        {
            if (cmbDersler.SelectedValue != null)
            {
                MySqlConnection con = VeritabaniBaglantisi.BaglantiGetir();
                con.Open();

                string query = "INSERT INTO SecilenDersler (OgrenciID, DersID, OnayDurumu) VALUES (@OgrenciID, @DersID, 'Beklemede')";
                MySqlCommand cmd = new MySqlCommand(query, con);
                  // Bu değeri kullanıcı girişinden alıyoruz.
                cmd.Parameters.AddWithValue("@DersID", cmbDersler.SelectedValue);

                cmd.ExecuteNonQuery();
                con.Close();

                MessageBox.Show("Ders başarıyla seçildi.");
                
            }
            else
            {
                MessageBox.Show("Lütfen bir ders seçin.");
            }
        }

        private void dgvSecilenDersler_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            
            {
                MySqlConnection con = VeritabaniBaglantisi.BaglantiGetir();
                con.Open();

                string query = "SELECT DersAdi, OnayDurumu FROM Dersler JOIN SecilenDersler ON Dersler.DersID = SecilenDersler.DersID WHERE SecilenDersler.OgrenciID = @OgrenciID";
                MySqlCommand cmd = new MySqlCommand(query, con);
               

                MySqlDataAdapter da = new MySqlDataAdapter(cmd);
                DataTable dt = new DataTable();
                da.Fill(dt);

                dgvSecilenDersler.DataSource = dt;
                con.Close();
            }
        }
    }
}
