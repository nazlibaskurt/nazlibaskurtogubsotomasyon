﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace OBS_Sistemi
{
    public partial class OgretmenForm : Form
    {
        public OgretmenForm()
        {
            InitializeComponent();
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void OgretmenForm_Load(object sender, EventArgs e)
        {
             void OgrenciDersleriniGoster()
            {
                MySqlConnection con = VeritabaniBaglantisi.BaglantiGetir();
                con.Open();

                string query = "SELECT Ogrenciler.Ad, Ogrenciler.Soyad, Dersler.DersAdi, SecilenDersler.OnayDurumu " +
                               "FROM SecilenDersler " +
                               "JOIN Ogrenciler ON SecilenDersler.OgrenciID = Ogrenciler.OgrenciID " +
                               "JOIN Dersler ON SecilenDersler.DersID = Dersler.DersID " +
                               "WHERE SecilenDersler.OnayDurumu = 'Beklemede'";

                MySqlDataAdapter da = new MySqlDataAdapter(query, con);
                DataTable dt = new DataTable();
                da.Fill(dt);

                dgvOgrenciDersleri.DataSource = dt;
                con.Close();
            }
        }

        private void btnDersOnayla_Click(object sender, EventArgs e)
        {
            if (dgvOgrenciDersleri.SelectedRows.Count > 0)
            {
                int secilenDersID = Convert.ToInt32(dgvOgrenciDersleri.SelectedRows[0].Cells["SecimID"].Value);

                MySqlConnection con = VeritabaniBaglantisi.BaglantiGetir();
                con.Open();

                string query = "UPDATE SecilenDersler SET OnayDurumu = 'Onaylandı' WHERE SecimID = @SecimID";
                MySqlCommand cmd = new MySqlCommand(query, con);
                cmd.Parameters.AddWithValue("@SecimID", secilenDersID);

                cmd.ExecuteNonQuery();
                con.Close();

                MessageBox.Show("Ders onaylandı.");
                
            }
            else
            {
                MessageBox.Show("Lütfen onaylamak için bir ders seçin.");
            }
        }

        private void btnDersRed_Click(object sender, EventArgs e)
        {
            if (dgvOgrenciDersleri.SelectedRows.Count > 0)
            {
                int secilenDersID = Convert.ToInt32(dgvOgrenciDersleri.SelectedRows[0].Cells["SecimID"].Value);

                MySqlConnection con = VeritabaniBaglantisi.BaglantiGetir();
                con.Open();

                string query = "UPDATE SecilenDersler SET OnayDurumu = 'Reddedildi' WHERE SecimID = @SecimID";
                MySqlCommand cmd = new MySqlCommand(query, con);
                cmd.Parameters.AddWithValue("@SecimID", secilenDersID);

                cmd.ExecuteNonQuery();
                con.Close();

                MessageBox.Show("Ders reddedildi.");
                
            }
            else
            {
                MessageBox.Show("Lütfen reddetmek için bir ders seçin.");
            }
        }
    }
}
