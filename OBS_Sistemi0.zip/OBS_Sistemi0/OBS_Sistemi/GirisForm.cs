﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;


namespace OBS_Sistemi
{
    public partial class GirisForm : Form
    {
        public GirisForm()
        {
            InitializeComponent();
        }

        private void btnGiris_Click(object sender, EventArgs e)
        {
            string kullaniciTuru = cmbKullaniciTuru.SelectedItem.ToString();
            string kullaniciAdi = txtKullaniciAdi.Text;
            string sifre = txtSifre.Text;

            if (kullaniciTuru == "Memur")
            {
                MemurForm memurForm = new MemurForm();
                memurForm.Show();
            }
            else if (kullaniciTuru == "Öğrenci")
            {
                OgrenciForm ogrenciForm = new OgrenciForm();
                ogrenciForm.Show();
            }
            else if (kullaniciTuru == "Öğretmen")
            {
                OgretmenForm ogretmenForm = new OgretmenForm();
                ogretmenForm.Show();
            }
            this.Hide();
        }
    }
}
